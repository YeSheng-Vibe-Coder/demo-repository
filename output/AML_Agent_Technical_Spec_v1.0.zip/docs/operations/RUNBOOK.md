# 运行指南

## 1. 实现范围

首版研究实现可执行显式账户调查、政策草案生成、独立特征样本准备、196 个组合的开发校准与验证门槛判断。真实数据验收仍在进行；接口或单元测试通过不等于检测效果通过。

实际调用链：TypeScript Markovian → Python 业务 API → NVIDIA Planner → Pydantic 决策/工具参数校验 → Zetaris 固定查询 → Observation → H-MEM → 下一轮。模型依据观察选择动作及 Replan，没有固定扩窗路径。

## 2. 配置

- Python 3.11+，项目 `.venv`；Node 22.7+（当前验证为 Node 25，原生 TypeScript transform 仍有实验特性提示）。
- 根目录 `.env.local`：`NVIDIA_API_KEY`、`ZETARIS_REST_URL`、`ZETARIS_API_KEY`、`ZETARIS_ORG_ID`。权限 600，Git 忽略，不进入提示词。
- Zetaris 经现有 SSH 隧道连接 Azure：8888 REST、3000 网页；无需 Nightshift 或本地模型权重。
- 本地 API token 自动生成在 `.runtime/api-token`，仅供 loopback 客户端，不打印。
- 数据凭据仍是现有管理员密钥：标签隔离由模块和固定模板实现，数据库 RBAC 强隔离尚未完成。

## 3. 启动与调查

项目根目录执行；显式源码路径适用于隔离执行环境，不依赖 editable 安装元数据。

```bash
PYTHONPATH=services/aml-api .venv/bin/python -m aml_agent.cli status
PYTHONPATH=services/aml-api .venv/bin/python -m aml_agent.cli serve
```

服务只监听 `127.0.0.1:8010`，OpenAPI 在 `/docs`。第二个终端：

```bash
PYTHONPATH=services/aml-api .venv/bin/python -m aml_agent.cli investigate CASE.json
PYTHONPATH=services/aml-api .venv/bin/python -m aml_agent.cli show RUN_UUID
PYTHONPATH=services/aml-api .venv/bin/python -m aml_agent.cli run RUN_UUID
```

将案例保存至 `.runtime/`，示例：

```json
{"account":{"bank":"011798","account":"800EA1EB0"},"start":"2022-08-04T00:00:00","as_of":"2022-08-05T00:00:00","split":"smoke"}
```

银行/账户保留前导零。不提供规则版本时明确标为显式账户烟雾调查，不能冒充规则告警。中断动作会停止等待对账，不静默重复查询；已完成 action_id 可幂等重放。调查完成不表示确认洗钱。

## 4. 规则与独立评估

```bash
PYTHONPATH=services/aml-api .venv/bin/python -m aml_agent.cli bootstrap
PYTHONPATH=services/aml-api .venv/bin/python -m aml_agent.cli prepare-cohort development
PYTHONPATH=services/aml-api .venv/bin/python -m aml_agent.cli prepare-cohort validation
PYTHONPATH=services/aml-api .venv/bin/python -m aml_agent.cli prepare-cohort test
```

草案只允许 fan_in、fan_out、receive_then_send；参数为 null，由独立程序校准。当前快照核验到 8 个段落，首批模板使用 P02/P03。14 个项目指标映射不等于已登记的 14 条官方法规原文。未知特征/字段/模板不能执行。

诊断样本按固定分区第一观察日抽取 100 个账户窗口，其中 10 个含发布者正例。48 小时特征历史可早于目标分区，但始终早于截止时间。跨分区账号重叠未消除。特征和标签分开保存在 `.runtime/evaluation-only/`。准备测试集不代表允许查看逐案测试结果或基于测试调参。

```bash
PYTHONPATH=services/aml-api .venv/bin/python -m aml_agent.cli calibrate .runtime/evaluation-only/development.features.json .runtime/evaluation-only/development.labels.json
PYTHONPATH=services/aml-api .venv/bin/python -m aml_agent.cli evaluate CALIBRATION_ID .runtime/evaluation-only/validation.features.json .runtime/evaluation-only/validation.labels.json
PYTHONPATH=services/aml-api .venv/bin/python -m aml_agent.cli publish-experiment GENERATION_ID CALIBRATION_ID EVALUATION_ID
```

仅 development 用于校准。独立验证必须完整、至少 100 个窗口且有 10 个正例，在匹配预算下 TP 增加且 precision 不下降；否则 hold/reject。富集样本不报告总体 precision；自然分布评估另行验收。无生产发布资格。

## 5. 硬限制与费用

每案最多 10 次模型请求（包括修复）、8 个动作、2 次 Replan、16 次 SQL。单请求预留 24000 输入/2048 输出 tokens，按实际 usage 结算，推理计入输出。没有透明重试、多模型比赛或 provider 回退。输入用 UTF-8 字节保守检查，可能提前拒绝较大 EvidencePacket。

180 秒客户端超时不代表源 SQL 已取消。异常结果不能当空数据；明细取第 201 行检测截断，并校验探测行的账户/时间边界。未知作用域、历史不足和过期 lease 都明确失败或暂缓。

NVIDIA 免费原型端点已验证可调用，账号剩余额度和账单信息尚未取得。Zetaris 消耗现有 Azure VM 资源。没有新增 Azure 资源、付费模型服务或 Nightshift 订阅。

## 6. 测试

```bash
.venv/bin/python -m pytest -q
node --experimental-transform-types --test services/orchestrator/worker.test.ts
```

官方引擎版本见 `vendor/meterless/PROVENANCE.json`，参考实现不是生产 SDK。其官方测试需要开发依赖 Vitest。宿主负责精确预算、案件权限和状态幂等。

## 7. 尚未通过的正式验收

- 真实模型调查的稳定完成率、Replan 和规则提议真实案例验收。
- 三个分区正式特征样本及独立效果评估；已有研究实验版本，但不具备生产发布资格。
- 自然分布总体效果、账号/网络重叠敏感性分析。
- 后台自动告警队列、周期监控调度、完整取消和中断对账界面；单轮告警及版本切换/回滚已有实现。
- 生产 RBAC、强数据快照隔离、分布式运行及生产部署。

## 8. 清理与恢复

旧 `scripts/`、`prototype/` 和一次性 profiling 脚本已移除；恢复快照为 `/private/tmp/hackson-process-code-20261022.tar.gz`。一次性 SQL 快照为 `/private/tmp/hackson-process-sql-20261022.tar.gz`。旧示例仓库移至 `/private/tmp/hackson-getting-started-20261022`，当前代码不依赖它。临时目录可能被系统清理，需长期保留时应移至持久备份。

历史文档在 `docs/archive/`。正式源码、必要测试、来源快照和验证结果保留；案件数据库及凭据不在本次清理范围。

### 调查重复动作与执行追踪

执行保护、Meterless 能力边界及回归验收见 [执行 Harness](../architecture/EXECUTION_HARNESS.md)。

使用 `PYTHONPATH=services/aml-api .venv/bin/python -m aml_agent.cli trace RUN_ID` 查看时间线。连续重复被阻止时，案件以 `insufficient_evidence / loop_detected` 结束，不能解释为模型不可用或调查已完成。


### 当前业务主线与诊断边界

默认 planner_variant=baseline；targeted 是未推广的样例实验。案件 finish 不调用 LLM 业务评审，只有契约、引用、范围和执行完整性检查。结论保存不代表标签确认洗钱。

样本逐笔标签校验、跨案归纳、实际 base_version 对照的独立 Rule Evaluator、实验登记和监控检查已贯通一轮研究运行，见 [实现对照](../architecture/IMPLEMENTATION_ALIGNMENT_AUDIT.md)。review-controls 和历史八次提示实验仅是离线诊断，不是规则更新验收。

### 规则驱动单轮研究运行

服务启动后，在项目根目录执行：

```bash
PYTHONPATH=services/aml-api .venv/bin/python -m aml_agent.cli rule-cycle --cases 3
```

此命令会实际调用模型、查询现有 VM 数据并可能登记新实验版本，不是只读展示。每轮固定父规则和数据清单，按标签盲排序调查 2–6 个开发告警；不足两个有效案件时不作跨案更新。按 ID 独立校验交易标签，Rule Proposer 只使用开发摘要；Rule Evaluator 用冻结验证比较实际父版本与候选版本。规则编译限制见技术规范 4.3。

回执在 `.runtime/rule-cycles/`；不可变 artifacts、模型角色用量与版本别名保存在私有 SQLite。`research-current` 指向新实验版本，旧案件固定父版本。监控为显式批检查，无后台调度；同批验证回查不算未来漂移证据。当前 20261022 运行结果见 `analysis/README.md`，仍有正例未识别和重复动作停止，不宣称检测效果验收通过。
